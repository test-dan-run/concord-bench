# Reference package template

A reference package hands finished references to Concord Bench (Datasets -> Import reference package).
Concord Label writes them; you can also make one by hand or with another tool. Zip the folder (or upload
the folder itself).

    reference_package/
      manifest.json      format "concord-reference-package", format_version 2, name, created_at,
                         label_types (asr and/or diar), counts {files, segments, hours},
                         audio_included (all | partial | none); optional language, tags, description,
                         scope, review, models, normaliser
      files.csv          path,sha256,duration,sample_rate - one row per audio file
      audio/<path>       the audio; a file Concord Bench already has (same sha256) may be left out
      refs/<one file>    the references, in any format the annotated upload reads (see the other
                         templates), matched to the audio by file name without the extension
      refs/attributes.json  optional labels to break scores down by:
                         {"files": {"<path>": {"condition": "clean"}},
                          "speakers": {"<path>": {"<speaker>": {"gender": "F"}}}}
                         Speaker labels are named speaker.<name>, e.g. speaker.gender. A record in a
                         JSONL or SegLST references file can also carry its own "attributes" object.

Add `"source": {"app", "install_id", "dataset_uid", "dataset_name"}` and `"export_version": 1, 2, ...`
to the manifest when the same dataset will be sent again: a package from the same source becomes a new
version of the dataset (scored references are never changed). A folder without manifest.json is read
like an annotated upload.

The full format is in CONTRACTS.md section 2 of the Concord Bench repository.
